<?php 

include 'slider.php';
// include 'kategori.php';
include 'produk.php';
include 'berita.php';
 ?>

