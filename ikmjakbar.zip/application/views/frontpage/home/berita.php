<style>
	.jumbotron {
	background-image: url("pjp");
	background-size: cover;
	}
</style>

<div class="jumbotron m-b-0" style="color:white; background-image: url('<?=base_url('icon/jakbar2.png')?>'); background-size: cover;">
	<div class="container">
  <h1 class="display-4">Ayo Lihat..</h1>
  <p class="lead m-b-2" style="color:white;" >Pemetaan Usaha Di Jakarta Barat!</p>
  <p class="lead p-t-1">
    <a class="btn  bo-rad-23 s-text2 bgwhite hov1 trans-0-4 btn-lg " href="<?=base_url('maps')?>" role="button">Menuju Peta</a>
  </p>
  </div>
</div>

