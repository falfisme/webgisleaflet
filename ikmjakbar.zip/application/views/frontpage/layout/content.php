<?php 
// mengambil data isi di controller (dari variable $isi)
if ( $isi ){
    $this->load->view($isi);
}
?>